package com.Natwest.springbootbankingUser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootBankingUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
