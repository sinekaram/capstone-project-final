package com.Natwest.springbootbankingFAQ;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootBankingFaqApplicationTests {

	@Test
	void contextLoads() {
	}

}
