package com.Natwest.loanapplicationbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanApplicationBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
